<?php
include('db_config.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Get the current username from session
$current_username = $_SESSION['username'];

// Get data from the edit profile form
$username = $_POST['username']; // This should be the same as $current_username
$name = $_POST['name'];
$password = md5($_POST['password']);

// Update user information
$updateSql = "UPDATE user SET name = '$name', password = '$password' WHERE username = '$current_username'";

if (mysqli_query($conn, $updateSql)) {
    // Successful update
    $_SESSION['success_message'] = "Profile updated successfully!";
    
    // Redirect to the edit profile page to show the message
    header("Location: editprofile.php");
    exit();
} else {
    // Error in update
    echo "Error: " . mysqli_error($conn);
}

// Close database connection
mysqli_close($conn);
?>
