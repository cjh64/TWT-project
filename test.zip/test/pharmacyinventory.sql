-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2024 at 08:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacyinventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `item` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `address` text NOT NULL,
  `order_date` date NOT NULL,
  `delivery_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `item`, `quantity`, `total_price`, `address`, `order_date`, `delivery_date`) VALUES
(9, 'Toong', 'Panadol', 1, 1.00, '23, Jalan Berjaya 8, Kawasan Perindustrian Taman Berjaya, Johor Bahru', '2024-07-02', '2024-07-02'),
(12, 'ali', 'Panadol', 1, 1.00, '12, Jalan D1,  Ixora Apartment, Ayer Keroh', '2024-07-02', '2024-07-04');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `expiry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`id`, `name`, `category`, `quantity`, `expiry_date`) VALUES
(2, 'Vitamin C', 'VITAMIN & MINERAL', 50, '2024-11-30'),
(3, 'Baby Lotion', 'MOTHER & BABY CARE', 30, '2024-08-15'),
(4, 'Fish Oil', 'SUPPLEMENT & NUTRITION', 200, '2026-01-10'),
(5, 'Calcium Tablets', 'VITAMIN & MINERAL', 75, '2025-09-25'),
(6, 'Organic Green Tea', 'HEALTH | ORGANIC FOODS & DRINKS', 120, '2024-10-05'),
(9, 'Multivitamin Gummies', 'VITAMIN & MINERAL', 150, '2026-03-18'),
(11, 'Zinc Supplements', 'VITAMIN & MINERAL', 60, '2025-05-30'),
(12, 'Chamomile Tea', 'HEALTH | ORGANIC FOODS & DRINKS', 100, '2024-12-25'),
(13, 'Infant Formula', 'MOTHER & BABY CARE', 45, '2024-07-10'),
(14, 'Vitamin D3', 'VITAMIN & MINERAL', 90, '2026-02-28'),
(17, 'Panadol', 'SUPPLEMENT & NUTRITION', 20, '2025-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `name`, `password`) VALUES
(2, 'admin', 'cjh', '16cedfd7f87d33a793f9b4c2e840f9e5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
