
<html>
<header></header>
    <style>

    footer{
            background-color: black;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>

    <body>
<footer>
        <p>&copy; Pharmacy Inventory Management System</p>
    </footer>

    </body>

    </html>