<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f0f0;
            background-image: url('2.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        #mainbody {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            width: 400px;
            max-width: 90%;
            text-align: center;
        }
        #title {
            font-size: 36px;
            font-family: 'Roboto Slab', serif;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: auto;
            margin-top: 20px; /* Added margin to separate from title */
        }
        td {
            padding: 10px;
            text-align: right;
            color: #333;
        }
        td input[type="text"],
        td input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        td input[type="text"]:focus,
        td input[type="password"]:focus {
            border-color: #666;
        }
        td input[type="submit"] {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #383838;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        td input[type="submit"]:hover {
            background-color: #555; /* Darker shade on hover */
        }
        a {
            text-decoration: none;
            color: #007bff;
            font-size: 14px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div id="mainbody">
        <form action="login_process.php" method="POST">
            <div id="title">
                Pharmacy Inventory Management System
            </div>
            <table>
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username" placeholder="Enter your username" pattern="[A-Za-z0-9]+" title="Please enter alphabet or numbers only!" required></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="password" placeholder="Enter your password" required></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="loginBtn" value="Login"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>
